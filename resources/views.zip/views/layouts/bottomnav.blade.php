<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">
  <head>
  
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">

      <!-- My CSS Files-->
    <link id="pagestyle" href="../assets/css/mobile.css" rel="stylesheet" />
    <link id="pagestyle" href="../assets/css/dosen.css" rel="stylesheet" />
    <link id="pagestyle" href="../assets/css/main.css" rel="stylesheet" />
    <link id="pagestyle" href="../assets/css/my-bootstrap.css" rel="stylesheet" />
      <!-- My CSS Files-->
  
      {{-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> --}}
      
      <script src="https://kit.fontawesome.com/a031935a14.js" crossorigin="anonymous"></script>
      <link href="../assets/css/nucleo-svg.css" rel="stylesheet" />
      {{-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"> --}}
      <!-- Lexa -->
      {{-- <link id="pagestyle" href="../assets/lexa/css/bootstrap.min.css" rel="stylesheet" />
      <link href="../assets/lexa/css/icons.min.css"  id="bootstrap-style" rel="stylesheet" type="text/css">
      <link href="../assets/lexa/css/app.min.css" id="pagestyle" rel="stylesheet" type="text/css"> --}}
      <!-- Lexa -->

  <head>
    <body>
    
      <div class="navbar" id="myNavbar">
        <a href="{{ url('get-status-dosen').'/' }}{{ $details->email_dosen }}" class="active">Status Hadir Dosen</a>
        <a href="{{ url('dashboard-dosen').'/' }}{{ $details->email_dosen }}">List Antrian Mahasiswa</a>
        <a href="{{ url('dosen').'/' }}{{ $details->email_dosen }}">Profil Dosen</a>
        <a href="#about">About</a>
        <a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="myFunction()">&#9776;</a>
      </div>


      @yield('content') <!-- Placeholder for page-specific content -->


      <!-- Include footer or other common elements here -->
  
{{-- Script untuk Navigasi V --}}
  <script>
    function myFunction() {
      var x = document.getElementById("myNavbar");
      if (x.className === "navbar") {
        x.className += " responsive";
      } else {
        x.className = "navbar";
      }
    }
  </script>
</body>
      @stack('scripts')
  
  <footer class="py-16 text-center text-sm text-black dark:text-white/70">
                    
  </footer>
  
  
  </html>