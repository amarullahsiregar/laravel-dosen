{{-- login.blade.php --}}
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link id="pagestyle" href="../assets/css/main.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <title>AIKADO | {{ $title }}</title>
    <!-- Tambahkan CSS Anda di sini -->
</head>
<body>
    <div class="login-container">
        <div class="row">
            <div class="col-md-6">
                
                <h1>{{ $title }} Dosen</h1>
                <form method="POST" action="">
                    @csrf
                    <div class="form-group">
                        <label for="email">Email:</label>
                        <input type="email" name="email" id="email" required autofocus>
                    </div>
                    <div class="form-group">
                        <label for="password">Password:</label>
                        <input type="password" name="password" id="password" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Login</button>
                </form>
                <small><a href="https://cekdos.my.id">daftar hadir dosen</a></small>
            </div>
            
        </div>
    </div>
</body>
</html>
